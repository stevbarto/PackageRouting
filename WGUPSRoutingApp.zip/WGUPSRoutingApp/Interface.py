import package_router
import datetime
import wgups_package


class Interface:
    """
    Interface class, controlls all display elements, user input, and overall logic to run the program.
    """
    # Instance variables used in running the interface
    time = ''
    status_list = ['HUB', 'ENROUTE', 'AT STOP']
    step1 = 0
    step2 = 0
    step3 = 0

    def __init__(self):
        """
        Constructor method for the interface object, starts the package router instance
        """
        self.router = package_router.PackageRouter()

    def run(self):
        """
        Run method, entry point for the interface to initiate. Begins data imports and designates the current time for
        the application methods.
        :return: None
        """
        # Imports locations and packages using the package router methods
        self.router.import_locations()
        self.router.import_packages()

        # Initiates the program run time at 8:00 am with the current year, month, and day
        index_date = datetime.datetime.now()
        self.time = datetime.datetime(index_date.year, index_date.month, index_date.day, 8, 00, 00, 00)

        # Initiates the main interface menu
        self.main_interface(self.time)

    def main_interface(self, time):
        """
        Main interface menu method, runs the main application menu.
        :param time: datetime object set to the start time for the work day (8:00 AM)
        :return: None
        """
        # Initiation of stop variable for running the main menu
        user_input = ''

        # =========================================================================================
        # ============================= Initiate main menu loop here ==============================
        # =========================================================================================
        while user_input != 'x' and user_input != 'X':
            # Print header
            print("\n\n----------WGUPS PACKAGE ROUTING----------")
            print("Run routes, press R\nSearch packages, press S\nExit program, press X\n")
            # Input prompt and message
            user_input = input("Enter selection: ")
            # Initiate the routes
            if user_input == 'r' or user_input == 'R':
                self.run_routes()
            if user_input == 's' or user_input == 'S':
                self.search_packages()

    def print_status(self, hour, minute):
        """
        Method to print the current status update for packages and truck distance.
        :param hour: int hour value
        :param minute: int minute value
        :return: None
        """
        # Print header for the status screen
        print("\n\n" + self.print_time(hour, minute))
        print("-------------------------------------------------------PACKAGE "
              "STATUS------------------------------------------------------")
        print("Trk ID    Pkg ID    Dest. Address                           Deadline       City                Zip "
              "Code      Weight    Status")
        print("------    ------    -------------                           --------       ----                "
              "--------      ------    ------")
        # Build the package list for display
        package_list = []
        for i in range(len(self.router.packages.table)):
            if self.router.packages.search(i + 1) is not None:
                package_list.append(self.router.packages.search(i + 1))

        # loop to get and print the package data
        for j in range(len(package_list)):

            package = package_list[j]

            truck_id = str(package.get_truck())

            gap1 = ""
            i = len(truck_id)
            while i < 10:
                gap1 = gap1 + "."
                i = i + 1

            package_id = str(package.get_id())

            gap2 = ""
            i = len(package_id)
            while i < 10:
                gap2 = gap2 + "."
                i = i + 1

            address = package.get_address()

            gap3 = ""
            i = len(address)
            while i < 40:
                gap3 = gap3 + "."
                i = i + 1

            deadline = self.print_time(package.get_deadline().hour, package.get_deadline().minute)

            gap4 = ""
            i = len(deadline)
            while i < 15:
                gap4 = gap4 + "."
                i = i + 1

            city = package.get_city()

            gap5 = ""
            i = len(city)
            while i < 20:
                gap5 = gap5 + "."
                i = i + 1

            zip_code = package.get_zip_code()

            weight = str(package.get_weight()) + " kg"

            gap6 = ""
            i = len(weight)
            while i < 10:
                gap6 = gap6 + "."
                i = i + 1

            status = package.get_status()
            # Print statement for each package
            print(truck_id + gap1 + package_id + gap2 + address + gap3 + deadline + gap4 + city + gap5
                  + zip_code + "........." + weight + gap6 + status)

        # Print the truck distances and total distance
        dist1 = self.router.trucks[0].route_distance
        length1 = len(self.router.trucks[0].package_queue)
        stop1 = self.router.trucks[0].next_stop.get_address()
        dist2 = self.router.trucks[1].route_distance
        length2 = len(self.router.trucks[1].package_queue)
        stop2 = self.router.trucks[1].next_stop.get_address()
        dist3 = self.router.trucks[2].route_distance
        length3 = len(self.router.trucks[2].package_queue)
        stop3 = self.router.trucks[2].next_stop.get_address()

        print("\nTruck Statuses:")
        print("Truck 1:")
        print("     Total distance: " + str(dist1))
        print("     Packages loaded: " + str(length1))
        print("     Next stop: " + stop1)
        print("Truck 2:")
        print("     Total distance: " + str(dist2))
        print("     Packages loaded: " + str(length2))
        print("     Next stop: " + stop2)
        print("Truck 3:")
        print("     Total distance: " + str(dist3))
        print("     Packages loaded: " + str(length3))
        print("     Next stop: " + stop3)
        combined = dist1 + dist2 + dist3
        print("Combined total distance: " + str(combined))

    def auto_load_special_cases(self, hour, minute):
        """
        Method which simulates user input to handle special cases of package.
        :param hour: int value for the hour
        :param minute: int value for the minutes
        :return: None
        """
        # Generate the current time in total minutes for comparison
        time = minute + (hour * 60)

        # If time is within parameters for the first set of special cases handle them
        if time < 555 and self.step1 == 0:
            # Package 3: Can only be on truck 2
            self.router.load_package(2, self.router.special_cases[0], hour,
                                     minute)
            # Package 6: Delayed on flight---will not arrive to depot until 9:05 am
            package = self.router.packages.search(self.router.special_cases[1])
            package.set_hold(9, 5)
            self.router.wait_list.append(self.router.special_cases[1])
            # Package 9: Wrong address listed
            package = self.router.packages.search(self.router.special_cases[2])
            package.set_hold(10, 15)
            self.router.wait_list.append(self.router.special_cases[2])

            truck = self.router.trucks[0]
            # Package 14: Must be delivered with 15, 19
            truck.load_package(self.router.special_cases[3], self.time.hour, self.time.minute, self.router)
            truck.load_package(15, self.time.hour, self.time.minute, self.router)
            truck.load_package(19, self.time.hour, self.time.minute, self.router)
            # Package 16: Must be delivered with 13, 19
            truck.load_package(self.router.special_cases[4], self.time.hour, self.time.minute, self.router)
            truck.load_package(13, self.time.hour, self.time.minute, self.router)
            truck.load_package(19, self.time.hour, self.time.minute, self.router)
            # Package 18: Can only be on truck 2
            self.router.load_package(2, self.router.special_cases[5], self.time.hour,
                                     self.time.minute)
            # Package 20: Must be delivered with 13, 15
            truck.load_package(self.router.special_cases[6], self.time.hour, self.time.minute, self.router)
            truck.load_package(13, self.time.hour, self.time.minute, self.router)
            truck.load_package(15, self.time.hour, self.time.minute, self.router)
            # Package 25: Delayed on flight---will not arrive to depot until 9:05 am
            package = self.router.packages.search(self.router.special_cases[7])
            package.set_hold(9, 5)
            self.router.wait_list.append(self.router.special_cases[7])
            # Package 28: Delayed on flight---will not arrive to depot until 9:05 am
            package = self.router.packages.search(self.router.special_cases[8])
            package.set_hold(9, 5)
            self.router.wait_list.append(self.router.special_cases[8])
            # Package 32: Delayed on flight---will not arrive to depot until 9:05 am
            package = self.router.packages.search(self.router.special_cases[9])
            package.set_hold(9, 5)
            self.router.wait_list.append(self.router.special_cases[9])
            # Package 36: Can only be on truck 2
            self.router.load_package(2, self.router.special_cases[10], self.time.hour,
                                     self.time.minute)
            # Package 38: Can only be on truck 2
            self.router.load_package(2, self.router.special_cases[11], self.time.hour,
                                     self.time.minute)

            # Remove all packages that were loaded at this point
            self.router.special_cases.pop(0)
            self.router.special_cases.pop(2)
            self.router.special_cases.pop(2)
            self.router.special_cases.pop(2)
            self.router.special_cases.pop(2)
            self.router.special_cases.pop(5)
            self.router.special_cases.pop(5)

            self.step1 = 1

        elif 555 <= time < 620 and self.step2 == 0:
            # Take wait list packages from above that can be loaded at this point in time and queue them
            self.router.package_load_queue.append(self.router.special_cases[0])
            package = self.router.packages.search(self.router.special_cases[0])
            package.waitlist = 0
            package.status = 1
            self.router.wait_list.pop(0)
            self.router.package_load_queue.append(self.router.special_cases[2])
            package = self.router.packages.search(self.router.special_cases[2])
            package.waitlist = 0
            package.status = 1
            self.router.wait_list.pop(1)
            self.router.package_load_queue.append(self.router.special_cases[3])
            package = self.router.packages.search(self.router.special_cases[3])
            package.waitlist = 0
            package.status = 1
            self.router.wait_list.pop(1)
            self.router.package_load_queue.append(self.router.special_cases[4])
            package = self.router.packages.search(self.router.special_cases[4])
            package.waitlist = 0
            package.status = 1
            self.router.wait_list.pop(1)
            self.router.special_cases.pop(0)
            self.router.special_cases.pop(1)
            self.router.special_cases.pop(1)
            self.router.special_cases.pop(1)

            self.step2 = 1

        elif time >= 620 and self.step3 == 0:
            # Change the address on the final package and queue it for loading
            package = self.router.packages.search(self.router.special_cases[0])
            package.set_address("410 S State St")
            package.set_city("Salt Lake CIty")
            package.set_zip_code("84111")

            self.router.package_load_queue.append(self.router.special_cases[0])
            package.waitlist = 0
            package.status = 1
            self.router.wait_list.pop(0)

            self.router.special_cases = []

            self.step3 = 1

    def print_time(self, hour, minute):
        """
        Method to print the time in proper format for display.
        :param hour: int hour value
        :param minute: int minute value
        :return: str object with the time in proper format
        """
        # If the hour comes back over 24, bring it back within bounds
        while hour > 24:
            hour = hour - 12

        # Dictate the proper hour number for the time of day, designate the right time of day string
        if hour == 24 or hour == 0:
            display_hour = str(hour - 12)
            display_t_o_d = "AM"
        elif 24 > hour > 11:
            display_hour = str(hour - 12)
            display_t_o_d = "PM"
        else:
            display_hour = str(hour)
            display_t_o_d = "AM"

        # Generate the minute portion and ensure it is formatted
        display_minute = str(minute)

        if len(display_minute) == 1:
            display_minute = '0' + display_minute
        # Return an assembled time string
        return display_hour + ':' + display_minute + ' ' + display_t_o_d

    def run_routes(self):
        """
        Method to iteratively run the truck routes until complete or midnight is reached.  Pause point can be
        designated to stop execution at a necessary time
        :return: None
        """

        print_hour = ''
        print_min = ''

        # input logic here to allow execution to be stopped at any time desired...
        input_choice = input("Do you want a stop time? Y or N: ")
        if input_choice == 'Y' or input_choice == 'y':
            input_choice = input("Enter time in 24hr format HH:MM: ")
            for i in range(len(input_choice)):
                if i < 2:
                    if input_choice[i] != ':':
                        print_hour = print_hour + input_choice[i]
                if i >= 2:
                    if input_choice[i] != ':':
                        print_min = print_min + input_choice[i]

            print_hour = int(print_hour)
            print_min = int(print_min)

            print("Print Hour: " + str(print_hour))
            print("Print minute: " + str(print_min))

        completion = 0
        end_of_day = ''
        end_hour = ''
        end_minute = ''

        display_time = (8 * 60)

        # Generate the hour value
        display_hour = int(display_time / 60)
        # Ensure the hour is within bounds
        while display_hour > 24:
            display_hour = display_hour - 12
        # Generate the display minute
        display_minute = int(display_time % 60)

        # 1 minute time interval for each loop.
        time_interval = 1
        # If no pause points are designated this determines how often a status should print during looping
        print_interval = 15
        # Control variable to determine when looping should stop
        all_delivered = 0

        # Load special cases and queue packages for initial load
        if len(self.router.special_cases) > 0:
            self.auto_load_special_cases(display_hour, display_minute)
            self.router.queue_packages()

        # ======================== Loop through trucks for loading ========================
        for i in range(len(self.router.trucks)):
            # If the truck has a driver and is at the hub:
            if self.router.trucks[i].driver != -1 and self.router.trucks[i].at_hub == 1:
                # Load and dispatch the truck
                self.router.load_truck(self.router.trucks[i], display_hour, display_minute,
                                       self.router.package_load_queue)
                self.router.trucks[i].toggle_at_hub()
                self.router.trucks[i].set_leg_time(display_time, self.router.get_stop_time(self.router.trucks[i]))

        # ==============================================================================================
        # ==================================== Initiate route loop here ================================
        # ==============================================================================================
        while display_time <= 1019:
            # Increment the display time
            display_time = display_time + time_interval

            # Generate the hour value
            display_hour = int(display_time / 60)
            # Ensure the hour is within bounds
            while display_hour > 24:
                display_hour = display_hour - 12
            # Generate the display minute
            display_minute = int(display_time % 60)

            # ======================= Loop through trucks for deliveries ========================
            for i in range(len(self.router.trucks)):
                # Get truck
                truck = self.router.trucks[i]

                # If the truck is not at the hub, handle delivery cases
                if truck.at_hub == 0:

                    if truck.next_stop.get_id() == 1:
                        truck.toggle_at_hub()

                    # Append the distance based on the elapsed time and route status
                    truck.update_mileage(time_interval)
                    # If the time hack is here, deliver packages
                    if display_time <= truck.leg_time < display_time + 1:
                        # If there are still packages left:
                        if len(truck.package_queue) > 0:
                            # Deliver any for this location, returns an array of IDs
                            delivered = truck.deliver_packages(display_hour, display_minute, self.router)
                            # Use array of IDs to update statuses
                            for j in range(len(delivered)):
                                self.router.packages.search(delivered[j]).set_status(3, display_hour, display_minute)
                            # Update data relating to stops and status
                            truck.complete_stop(display_hour, display_minute)
                            truck.set_leg_time(display_time, self.router.get_stop_time(truck))
                        # If the truck is empty, head home now to reload or complete
                        elif truck.next_stop.get_id() == 1:
                            truck.at_hub = 1
                # If the truck is at the hub:
                elif truck.at_hub == 1:
                    if truck.driver == -1:
                        continue

                    # And if there are still special cases, handle them
                    if len(self.router.special_cases) > 0:
                        self.auto_load_special_cases(display_hour, display_minute)
                    # Queue, load, and dispatch
                    self.router.queue_packages()
                    self.router.load_truck(self.router.trucks[i], display_hour, display_minute,
                                               self.router.package_load_queue)

                    if len(truck.package_queue) > 0:
                        truck.toggle_at_hub()
                        truck.set_leg_time(display_time, self.router.get_stop_time(truck))

                if display_hour == print_hour and display_minute == print_min:
                    self.print_status(display_hour, display_minute)
                    if all_delivered == 1:
                        print("All Packages Delivered, end of day at " + self.print_time(end_hour, end_minute))

            # Logic to handle printing instructions
            if display_minute % print_interval == 0:
                if print_hour == '' and print_min == '':
                    self.print_status(display_hour, display_minute)

            # Determine if packages are delivered or if its midnight, if so end the loop.
            all_delivered = 1
            for i in range(self.router.packages.size):
                package_status = self.router.packages.search(i + 1).status
                if package_status != 3:
                    all_delivered = 0

            if all_delivered == 1:
                if completion == 0:
                    self.print_status(display_hour, display_minute)
                    end_hour = display_hour
                    end_minute = display_minute

                completion = 1

                # print("All Packages Delivered, end of day at " + self.print_time(end_hour, end_minute))

            if display_time >= 1440:
                all_delivered = 1
                self.print_status(display_hour, display_minute)
                print("Its midnight! All your drivers went home!!!!")

    def search_packages(self):
        """
        Method that takes search terms and prints search results
        :return:
        """
        id = ''

        while id != 'x' or id != 'X':

            address = ''
            deadline_hour = ''
            deadline_minute = ''
            city = ''
            zip_code = ''
            weight = ''
            status = ''

            results = []

            print("\n\nSearch Menu")
            print("Enter search terms or X to exit search menu")

            id = input("Enter ID number: ")
            if id == 'x' or id == 'X':
                break
            address = input("Enter Address: ")
            if address == 'x' or address == 'X':
                break
            deadline_hour = input("Enter deadline hour: ")
            if deadline_hour == 'x' or deadline_hour == 'X':
                break
            if deadline_hour != '':
                deadline_minute = input("Enter deadline minutes: ")
                if deadline_hour != '' and deadline_minute == '':
                    deadline_minute = 0
                if deadline_minute == 'x' or deadline_minute == 'X':
                    break
            deadline_tod = ''
            if deadline_hour != '':
                while deadline_tod != 'AM' and deadline_tod != 'PM':
                    deadline_tod = input("Enter AM or PM: ")
                    if deadline_tod == 'x' or deadline_tod == 'X':
                        break
            if deadline_tod == 'x' or deadline_tod == 'X':
                break
            city = input("Enter city: ")
            if city == 'x' or city == 'X':
                break
            zip_code = input("Enter zip code: ")
            if zip_code == 'x' or zip_code == 'X':
                break
            weight = input("Enter weight: ")
            if weight == 'x' or weight == 'X':
                break
            status = input("Enter status: ")
            if status == 'x' or status == 'X':
                break

            for i in range(self.router.packages.size):
                results.append(self.router.packages.search(i + 1))

            integer = 1

            for i in range(len(id)):
                if self.router.is_num(id[i]) == 0:
                    integer = 0

            if id != '':
                if integer == 1:
                    id = int(id)
                    i = 0
                    size = len(results)
                    while i < size:
                        if results[i].get_id() != id:
                            null = results.pop(i)
                            size = len(results)
                            continue
                        i = i + 1
                else:
                    print("Invalid ID input!\n")

            if address != '':
                i = 0
                size = len(results)
                while i < size:
                    if self.contains(results[i].get_address(), address) == 0:
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if deadline_hour != '':

                if deadline_tod == 'PM':
                    if int(deadline_hour) < 12:
                        deadline_hour = str(int(deadline_hour) + 12)

                i = 0
                size = len(results)
                while i < size:
                    if str(results[i].get_deadline().hour) != deadline_hour:
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if deadline_minute != '':
                i = 0
                size = len(results)
                while i < size:
                    if str(results[i].get_deadline().minute) != deadline_minute:
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if city != '':
                i = 0
                size = len(results)
                while i < size:
                    if self.contains(results[i].get_city(), city) == 0:
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if zip_code != '':
                i = 0
                size = len(results)
                while i < size:
                    if self.contains(results[i].get_zip_code(), zip_code):
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if weight != '':
                i = 0
                size = len(results)
                while i < size:
                    if results[i].get_weight() != weight:
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            if status != '':
                i = 0
                size = len(results)
                while i < size:
                    if self.contains(results[i].get_status(), status):
                        null = results.pop(i)
                        size = len(results)
                        continue
                    i = i + 1

            print("\nSearch Results")
            print("ID | Address | Deadline | City | Zip Code | Weight | Status")
            for i in range(len(results)):
                time = self.print_time(results[i].get_deadline().hour, results[i].get_deadline().minute)

                print(str(results[i].get_id()) + " | " + results[i].get_address() + " | " + time +
                      " | " + results[i].get_city() + " | " + results[i].get_zip_code() + " | " +
                      str(results[i].get_weight()) + " | " + results[i].get_status())

    def contains(self, source_string, sub_string):

        is_contained = 0

        if len(source_string) == len(sub_string):
            is_contained = 1
            for i in range(len(source_string)):
                if source_string[i] != sub_string[i]:
                    is_contained = 0

        for i in range(len(source_string) - len(sub_string)):
            same_string = 1
            for j in range(len(sub_string)):
                if source_string[i + j] != sub_string[j]:
                    same_string = 0
            if same_string == 1:
                is_contained = 1
                break

        return is_contained


    def insert_package(self):
        """
        Methat that takes input to insert a package into the hash table
        :return: None
        """
        user_input = ''

        while user_input != 'x' or user_input != 'X':
            id = ''
            address = ''
            deadline_hour = ''
            deadline_minute = ''
            city = ''
            zip_code = ''
            weight = ''
            status = ''

            results = []

            print("\n\nInsert Menu")
            print("Enter package details or X to exit search menu")

            id = input("Enter ID number: ")
            address = input("Enter Address: ")
            deadline_hour = input("Enter deadline hour: ")
            deadline_minute = input("Enter deadline minutes: ")
            city = input("Enter city: ")
            zip_code = input("Enter zip code: ")
            weight = input("Enter weight: ")
            status = input("Enter status: ")

            deadline = datetime.datetime(self.time.year, self.time.month, self.time.day, deadline_hour, deadline_minute)

            package = wgups_package.package(id, address, deadline, city, zip_code, weight, status)

            self.router.packages.insert(package)

            return
