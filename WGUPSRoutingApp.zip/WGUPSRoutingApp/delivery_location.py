class DeliveryLocation:
    """
    DeliveryLocation class for the package router application
    """
    def __init__(self, id, name, address, zip_code, hub):
        """
        DeliveryLocation constructor method
        :param id: int id value
        :param name: str name value
        :param address: str address value
        :param zip_code: str zip code value
        :param hub: Hub object
        """
        self.id = id
        self.name = name
        self.address = address
        self.zip_code = zip_code
        self.hub = hub

    def get_id(self):
        """
        Method returns the location ID value
        :return: int ID value
        """
        return self.id

    def set_name(self, name):
        """
        Method sets the name value for the location
        :param name: str name value
        :return: None
        """
        self.name = name

    def get_name(self):
        """
        Method returns the name value for the location
        :return: str name value
        """
        return self.name

    def set_address(self, address):
        """
        Method sets the address value for the location
        :param address: str address value
        :return: None
        """
        self.address = address

    def get_address(self):
        """
        Method returns the address value for the location
        :return: str address value
        """
        return self.address
