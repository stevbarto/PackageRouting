class Driver:
    """
    Driver class for the package router application
    """

    def __init__(self, id):
        """
        Constructor method for the driver class
        :param id: int id value
        """
        self.id = id
