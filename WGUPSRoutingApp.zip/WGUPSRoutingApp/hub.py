class Hub:
    """
    Hub class for the package router application.  Creates a hub object from which delivery routes start and return.
    """
    delivery_locations = []

    def __init__(self, id, name, address, city, state, zip_code):
        """
        Constructor method for the hub class.
        :param id: int id value
        :param name: str name value
        :param address: str address velue
        :param city: str city value
        :param state: str state value
        :param zip_code: str zip_code value
        """
        self.id = id
        self.name = name
        self.address = address
        self.city = city
        self.state = state
        self.zip_code = zip_code

    def add_location(self, delivery_location):
        """
        Method adds a location to the hub obhect
        :param delivery_location: delivery_location object
        :return: None
        """
        self.delivery_locations.append(delivery_location)

    def get_location(self, location_id):
        """
        Method returns the location object matching the parameter
        :param location_id: int id value
        :return: delivery_location object
        """
        for i in range(len(self.delivery_locations)):
            if location_id == self.delivery_locations[i].id:
                return self.delivery_locations[i]

    def remove_location(self, location_id):
        """
        Method removes a location from the hub object
        :param location_id: int location id value
        :return: None
        """
        for i in range(len(self.delivery_locations)):
            if location_id == self.delivery_locations[i].id:
                self.delivery_locations.remove(self.delivery_locations[i])

    def get_address(self):
        """
        Method returns the hub address
        :return: str address value
        """
        return self.address

    def get_id(self):
        """
        Method returns the id value of the hub
        :return: int id value
        """
        return self.id
