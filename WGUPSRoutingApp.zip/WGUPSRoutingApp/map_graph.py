class MapGraph:
    """
    Mep Graph class, creates a map graph represented by an adjacency matrix
    """
    adj_matrix = []

    def __init__(self):
        """
        Constructor method for the map graph object
        """
        self.size = 0

    def insert_vertex(self):
        """
        Method inserts a vertex in the graph
        :return: None
        """
        # Insert a vertex into the adjacency matrix.
        self.adj_matrix.append([])
        self.size = self.size + 1

    def insert_edge(self, vertex, edge, distance):
        """
        Method inserts an edge in the graph
        :param vertex: delivery_location object
        :param edge: delivery_location object
        :param distance: float distance value
        :return: None
        """
        # Insert an edge into the adjacency matrx for the designated vertex, edge index in the list will be the
        # distance.
        v_id = vertex.get_id() - 1
        e_id = edge.get_id() - 1
        row = self.adj_matrix[v_id]
        row.insert(e_id, distance)
        if v_id != e_id:
            row = self.adj_matrix[e_id]
            row.insert(v_id, distance)

    def get_vertex(self, id):
        """
        Method returns a vertex object from the map
        :param id: int id value
        :return: delivery_location object
        """
        return self.adj_matrix[id - 1][0]


