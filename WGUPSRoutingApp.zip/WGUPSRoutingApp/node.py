class Node:
    """
    Node class for the linked list and graph data structures.
    """
    next_node = None
    assigned = 0

    def __init__(self, last_node, item, value):
        """
        Constructor mehtod for the Node class
        :param last_node: Node object of preceding node
        :param item: Object to insert in Node
        :param value: Numerical value for use when weighting an adjacency list in a graph
        """
        self.last_node = last_node
        self.item = item
        self.value = value

    def get_value(self):
        """
        Method returns the wighted value for the Node when used as an edge
        :return: Numerical value, int or float depending on value added
        """
        return self.value

    def get_item(self):
        """
        Returns the object stored as the item
        :return: Object
        """
        return self.item

    def set_assigned(self):
        """
        Method sets assigned value to track traversal in a greph
        :return:
        """
        if self.assigned == 0:
            self.assigned = 1
        else:
            self.assigned = 1