import driver
import hub
import wgups_hash_table


class Truck:
    """
    Truck class for the package router program
    """

    # Constant varibles
    AVG_SPEED = 18
    MAX_LOAD = 16

    def __init__(self, id, hub):
        """
        Truck class constructor method
        :param id: int id value
        :param hub: hub object
        """
        self.last_stop = -1
        self.next_stop = -1
        self.id = id
        self.package_queue = []
        self.route_queue = []
        self.dist_queue = []
        self.driver = -1
        self.weight = 0
        self.load = 0
        self.route_distance = 0.0
        self.stop_hour = 0
        self.stop_min = 0
        self.at_hub = 1
        self.hub = hub
        self.last_stop = hub
        self.next_stop = hub
        self.leg_time = 0
        self.at_stop = 0
        self.stop_dist  = 0.0

    def load_package(self, package, hour, min, package_router):
        """
        Method loads a package into the truck object
        :param package_router:
        :param package: wgups_package object
        :param hour: int hour value
        :param min: int minute value
        :return: None
        """

        # Check if the package is already here
        present = 0
        for i in range(len(self.package_queue)):
            if self.package_queue[i] == package:
                present = 1

        # If not, load it
        if present == 0:
            if len(self.package_queue) <= self.MAX_LOAD:
                self.package_queue.append(package)
                current_package = package_router.packages.search(package)
                current_package.set_truck(self.id)
                current_package.set_status(2, hour, min)
                self.load = self.load + 1
                self.weight = self.weight + current_package.get_weight()

    def deliver_packages(self, hour, minute, router):
        """
        Method delivers packages for the location stored in the next_stop variable
        :param router:
        :param hour: int hour value
        :param minute: int minute value
        :return: int list of IDs delivered here
        """
        # Get the address for checking
        if len(self.route_queue) > 0:
            location_address = self.next_stop.get_address()
        else:
            location_address = self.next_stop.get_address()

        delivered_id = []
        j = 0
        size = len(self.package_queue)
        # Loop through packages and deliver any with the above address
        while j < size:
            id = self.package_queue.pop(0)
            package = router.packages.search(id)
            if package.get_address() == location_address:
                package.set_status(2, hour, minute)
                delivered_id.append(package.get_id())
                self.load = self.load - 1
                size = len(self.package_queue)
            else:
                self.package_queue.append(id)
            j = j + 1
        return delivered_id

    def set_driver(self, driver):
        """
        Method assigns a driver to the truck object
        :param driver: Driver object
        :return: None
        """
        self.driver = driver

    def get_load(self):
        """
        Method returns the number of packages loaded in the truck
        :return: int load value
        """
        return self.load

    def add_stop(self, location):
        """
        Method adds a stop to this truck route queue
        :param location: delivery_location object
        :return: None
        """
        contains = 0
        for i in range(len(self.route_queue)):
            if self.route_queue[i].get_id() == location.get_id():
                contains = 1

        if contains == 0:
            self.route_queue.append(location)

    def complete_stop(self, hour, min):
        """
        Method updates
        :param hour:
        :param min:
        :return:
        """
        self.stop_hour = hour
        self.stop_min = min

        if len(self.route_queue) == 0:
            self.last_stop = self.next_stop
            self.next_stop = self.hub

        elif len(self.route_queue) >= 1:
            self.last_stop = self.next_stop
            self.next_stop = self.route_queue.pop(0)


    def set_next_stop(self, stop):
        """
        Method sets the next stop for the truck.
        :param stop: delivery_location object
        :return: None
        """
        self.next_stop = stop

    def get_next_leg(self):
        """
        Method returns the last and current stops for the truck object
        :return: list of delivery_location objects
        """
        leg = [self.last_stop, self.next_stop]
        return leg

    def toggle_at_hub(self):
        """
        Method toggles the at at_hub value between at hub and not at hub
        :return: None
        """
        if self.at_hub == 1:
            self.at_hub = 0
        else:
            self.at_hub = 1

    def update_mileage(self, interval):
        # d = st, to get distance multiply mi/hr times the time interval which is in minutes, convert to hr by /60.
        distance = self.AVG_SPEED * (interval/60)
        if self.at_hub == 0:
            self.route_distance = self.route_distance + distance

    def set_leg_time(self, current_time, leg_time):

        self.leg_time = current_time + leg_time


