class hashTable:
    """
    HashTable class creates a hash table for storing packages in the WGUPS package router application
    """
    def __init__(self, start_size, threshold):
        """
        Constructor method for the hash table
        :param start_size: int value, designates initial internal list size
        :param threshold: int value, 1 for no chaining, more for chaining
        """
        self.size = 0
        self.listSize = start_size
        self.table = []
        self.threshold = threshold
        for i in range(start_size):
            self.table.append([])

    def insert(self, package):
        """
        Insert method inserts a package into the hash table
        :param id: int id value
        :param package: package object
        :return: None
        """
        # If the internal list is getting too close to full, call the rehash method
        if self.size == int(self.listSize * 0.8):
            self.reHash()

        # Identify a bucket index by hashing the key
        index = self.hash(package.get_id())

        # Attempt to insert the item, if the bucket is full/occupied, user quadratic probing until it can load
        i = 0
        probe_index = index
        while i < self.listSize:
            # Calculate the index
            probe_index = probe_index + i * i
            # Loop to ensure the probe index is within the list size
            while probe_index >= self.listSize:
                probe_index = probe_index - self.listSize
            # Insert if able
            if len(self.table[probe_index]) < self.threshold:
                self.table[probe_index].append(package)
                self.size = self.size + 1
                return

            i = i + 1

        #self.reHash()
        #self.insert(id, package)

    def search(self, package_id):
        """
        Method returns the object matching the search criteria
        :param package_id: int id value
        :return: package object
        """
        # Create a working package using the parameters
        item = package_id

        # Hash the key to get the index
        index = self.hash(item)

        # Compare each item in the bucket and return the one with the matching key
        #  If the bucket does not contain the matching key, return nothing, throw exception
        reference_list = self.table[index]

        j = 0
        probe_index = index
        while j < self.listSize:
            # probe_index = probe_index + 1
            probe_index = probe_index + j * j
            while probe_index >= self.listSize:
                probe_index = probe_index - self.listSize

            reference_list = self.table[probe_index]

            for i in range(len(reference_list)):
                package = reference_list[i]

                if package.get_id() == item:
                    return package

            j = j + 1

    def remove(self, package_id):
        """
        Method removes the package matching the id
        :param package_id: int id value
        :return: None
        """
        item = package_id

        # definition of remove
        index = self.hash(item)

        # If the index contains the matching key, remove that item and decrease size
        #  If the bucket does not contain the key, throw exception
        #reference_list = self.table[index]

        j = 0
        probe_index = index
        while j < self.listSize:
            # probe_index = probe_index + 1
            probe_index = probe_index + j * j
            while probe_index >= self.listSize:
                probe_index = probe_index - self.listSize

            reference_list = self.table[probe_index]

            for i in range(len(reference_list)):
                package = reference_list[i]

                if package.get_id() == item:
                    self.table.pop(item)
                    self.size = self.size - 1
                    return

            j = j + 1

        raise RuntimeError("Item not found!")

    def hash(self, package_id):
        """
        Method takes a package ID and returns a hashed index
        :param package_id: int ID vlaue
        :return: int index value
        """
        # Ensure the parameter is an integer, make it the key
        if isinstance(package_id, int):
            key = package_id
        else:
            key = package_id.get_id()

        # Use the id and the list size to hash and determine an index for insertion
        if self.listSize >= key:
            hash_code = self.listSize % key
        else:
            hash_code = key % self.listSize

        return hash_code

    def reHash(self):
        """
        Method increases the internal list size to accomodate more objects, then re-inserts them by hashing the now
        size
        :return:
        """
        # Swap out existing table and create a new one
        newTable = []
        oldTable = self.table

        # Increase the list size and populate the new table
        self.listSize = self.listSize * 2
        i = 0
        while i < self.listSize:
            newTable.append([])
            i = i + 1

        # Put new table in place
        self.table = newTable
        self.size = 0

        # Iterate over the old table and re-insert the items into the new table.
        for i in range(len(oldTable)):
            if len(oldTable[i]) > 0:
                for j in range(len(oldTable[i])):
                    same_item = oldTable[i][j]
                    if same_item is not None:
                        self.insert(same_item)

